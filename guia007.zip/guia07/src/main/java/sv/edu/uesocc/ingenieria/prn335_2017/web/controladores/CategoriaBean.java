/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sv.edu.uesocc.ingenieria.prn335_2017.web.controladores;

import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import sv.edu.uesocc.ingenieria.prn335_2017.datos.acceso.CategoriaFacadeLocal;
import sv.edu.uesocc.ingenieria.prn335_2017.datos.acceso.GenericFacadeLocal;
import sv.edu.uesocc.ingenieria.prn335_2017.datos.definiciones.Categoria;

/**
 *
 * @author usuario
 */
@Named(value = "categoriaBean")
@ViewScoped
public class CategoriaBean extends GenericManagedBean<Categoria> implements Serializable {

  
    public CategoriaBean() {
    }
    @EJB
    CategoriaFacadeLocal catfaloc;
    Categoria cat;
    
    @Override
    protected GenericFacadeLocal<Categoria> getFacadeLocal() {
        return catfaloc;
    }

    @Override
    public Categoria getEntity() {
        return cat;
    }
    
    @Override
    public void reset() {
        cat.setActivo(false);
        cat.setIdCategoria(null);
        cat.setDescripcion(null);
        cat.setNombre(null);
        
    }

    @Override
    public void nuevo() {
        cat = new Categoria();
//        setMostrar(true);
//        setCrudBtns(true);
    }

    @Override
    public void cancelar() {
        cat = new Categoria();
//        setMostrar(false);
//        setCrudBtns(true);
    }

    public List<Categoria> getListaDatos() {
        return listaDatos;
    }

    public void setListaDatos(List<Categoria> listaDatos) {
        this.listaDatos = listaDatos;
    }
    
}
