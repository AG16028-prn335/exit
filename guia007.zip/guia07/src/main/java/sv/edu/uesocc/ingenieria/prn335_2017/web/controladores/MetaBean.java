/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sv.edu.uesocc.ingenieria.prn335_2017.web.controladores;

import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.Dependent;
import sv.edu.uesocc.ingenieria.prn335_2017.datos.acceso.GenericFacadeLocal;
import sv.edu.uesocc.ingenieria.prn335_2017.datos.acceso.MetaFacadeLocal;
import sv.edu.uesocc.ingenieria.prn335_2017.datos.definiciones.Categoria;

/**
 *
 * @author usuario
 */
@Named(value = "metaBean")
@Dependent
public class MetaBean extends GenericManagedBean<Categoria> implements Serializable {

   
    public MetaBean() {
    }
    
   @EJB
    MetaFacadeLocal metfaloc;
    Meta met;
    
    @Override
    protected GenericFacadeLocal<Meta> getFacadeLocal() {
        return metfaloc;
    }

    @Override
    public Categoria getEntity() {
        return met;
   }
    
    @Override
    public void reset() {
        met.setActivo(false);
        met.setIdCategoria(null);
        met.setDescripcion(null);
        met.setNombre(null);
        
    }

    @Override
    public void nuevo() {
        met = new Categoria();
//        setMostrar(true);
//        setCrudBtns(true);
    }

    @Override
    public void cancelar() {
        met = new Categoria();
//        setMostrar(false);
//        setCrudBtns(true);
    }

    public List<Meta> getListaDatos() {
        return listaDatos;
    }

    public void setListaDatos(List<Meta> listaDatos) {
        this.listaDatos = listaDatos;
    }
     
}
